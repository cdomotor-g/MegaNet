Gatton, 23 June 2026 - two photos from the gauge.
